// Listen for messages from the content script and take appropriate action
browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Handle the formatted Mathematica data
  
});

