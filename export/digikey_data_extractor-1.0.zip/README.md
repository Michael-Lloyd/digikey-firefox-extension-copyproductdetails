# Digikey product properties table extractor 

![](usage.png)
![](usage2.png)
